<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20240329215158 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE client_entree_chaude DROP FOREIGN KEY FK_87936D82196C58B6');
        $this->addSql('ALTER TABLE client_entree_chaude DROP FOREIGN KEY FK_87936D8219EB6921');
        $this->addSql('DROP TABLE client_entree_chaude');
        $this->addSql('DROP TABLE entree_chaude');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE client_entree_chaude (client_id INT NOT NULL, entree_chaude_id INT NOT NULL, INDEX IDX_87936D8219EB6921 (client_id), INDEX IDX_87936D82196C58B6 (entree_chaude_id), PRIMARY KEY(client_id, entree_chaude_id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB COMMENT = \'\' ');
        $this->addSql('CREATE TABLE entree_chaude (id INT AUTO_INCREMENT NOT NULL, title VARCHAR(255) CHARACTER SET utf8mb4 DEFAULT NULL COLLATE `utf8mb4_unicode_ci`, PRIMARY KEY(id)) DEFAULT CHARACTER SET utf8mb4 COLLATE `utf8mb4_unicode_ci` ENGINE = InnoDB COMMENT = \'\' ');
        $this->addSql('ALTER TABLE client_entree_chaude ADD CONSTRAINT FK_87936D82196C58B6 FOREIGN KEY (entree_chaude_id) REFERENCES entree_chaude (id) ON DELETE CASCADE');
        $this->addSql('ALTER TABLE client_entree_chaude ADD CONSTRAINT FK_87936D8219EB6921 FOREIGN KEY (client_id) REFERENCES client (id) ON DELETE CASCADE');
    }
}
